"""
Load a plsqlmig-generated .cypher file into a Neo4j database.

Usage:
    pip install neo4j
    python load_cypher.py out.cypher --uri bolt://localhost:7687 \
        --user neo4j --password YOUR_PASSWORD [--database neo4j] [--wipe]

Notes:
- Statements are split in a quote-aware way, so semicolons and newlines that
  appear *inside* string properties (e.g. a SqlStatement's text / spark_sql)
  do not break the split.
- CREATE CONSTRAINT statements are run on their own (Neo4j forbids mixing
  schema and data changes in one transaction); data MERGEs are batched.
"""
from __future__ import annotations

import argparse
import sys
from typing import List

from neo4j import GraphDatabase


def split_statements(text: str) -> List[str]:
    """Split on ';' that are outside single-quoted strings.

    The generator quotes property values with single quotes and escapes inner
    quotes as \\'. We track that state so ';' / newlines inside a value are
    not treated as statement terminators.
    """
    stmts: List[str] = []
    buf: List[str] = []
    in_str = False
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if in_str:
            if ch == "\\" and i + 1 < n:        # escaped char inside string
                buf.append(ch)
                buf.append(text[i + 1])
                i += 2
                continue
            if ch == "'":
                in_str = False
            buf.append(ch)
        else:
            if ch == "'":
                in_str = True
                buf.append(ch)
            elif ch == ";":
                stmt = "".join(buf).strip()
                if stmt:
                    stmts.append(stmt)
                buf = []
            else:
                buf.append(ch)
        i += 1
    tail = "".join(buf).strip()
    if tail:
        stmts.append(tail)
    return stmts


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Load a .cypher file into Neo4j")
    ap.add_argument("cypher_file")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", default="neo4j")
    ap.add_argument("--database", default=None, help="target database (Neo4j 4+)")
    ap.add_argument("--batch", type=int, default=500, help="data statements per transaction")
    ap.add_argument("--wipe", action="store_true",
                    help="DELETE everything in the database first")
    args = ap.parse_args(argv)

    with open(args.cypher_file, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()

    statements = split_statements(text)
    constraints = [s for s in statements if s.upper().startswith("CREATE CONSTRAINT")]
    data_stmts = [s for s in statements if not s.upper().startswith("CREATE CONSTRAINT")]
    print(f"Parsed {len(statements)} statement(s): "
          f"{len(constraints)} constraint(s), {len(data_stmts)} data statement(s)")

    driver = GraphDatabase.driver(args.uri, auth=(args.user, args.password))
    sess_kwargs = {"database": args.database} if args.database else {}

    try:
        driver.verify_connectivity()
    except Exception as e:
        print(f"ERROR: cannot connect to {args.uri} as '{args.user}': {e}")
        print("Check the bolt URI, username, and password (and that Neo4j is running).")
        driver.close()
        return 2

    with driver.session(**sess_kwargs) as session:
        if args.wipe:
            print("Wiping existing data ...")
            session.run("MATCH (n) DETACH DELETE n")

        # Constraints: one transaction each (schema changes can't mix with data).
        for c in constraints:
            try:
                session.run(c)
            except Exception as e:
                print(f"  constraint skipped ({e.__class__.__name__}): {c[:80]}")

        # Data: batched explicit transactions for speed.
        total = len(data_stmts)
        done = 0
        for start in range(0, total, args.batch):
            chunk = data_stmts[start:start + args.batch]
            with session.begin_transaction() as tx:
                for s in chunk:
                    try:
                        tx.run(s)
                    except Exception as e:
                        print(f"  FAILED: {e.__class__.__name__}: {s[:120]}")
                        raise
                tx.commit()
            done += len(chunk)
            print(f"  loaded {done}/{total} data statements")

    driver.close()
    print("Done. Open Neo4j Browser and try:  MATCH (n) RETURN n LIMIT 100")
    return 0


if __name__ == "__main__":
    sys.exit(main())
