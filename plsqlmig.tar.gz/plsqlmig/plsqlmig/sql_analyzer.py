"""
SQL statement analyzer built on sqlglot.

For each DML/query statement found by the structural parser, this:
  - identifies tables read vs written,
  - extracts set-based signals (joins, aggregates, window funcs, group by),
  - flags Oracle-specific constructs that complicate Spark migration,
  - attempts an Oracle -> Spark SQL transpile.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Set, Optional

import sqlglot
from sqlglot import exp


@dataclass
class StmtAnalysis:
    kind: str
    reads: Set[str] = field(default_factory=set)
    writes: Set[str] = field(default_factory=set)
    columns: Set[str] = field(default_factory=set)
    joins: int = 0
    aggregates: int = 0
    window_funcs: int = 0
    has_group_by: bool = False
    operations: List[str] = field(default_factory=list)
    oracle_specific: List[str] = field(default_factory=list)
    spark_sql: Optional[str] = None
    parse_ok: bool = True


# Oracle constructs that don't map cleanly to Spark SQL.
_ORACLE_FLAGS = {
    exp.Connect: "connect_by_hierarchical",
}
_ORACLE_FUNC_NAMES = {"SYS_GUID", "NVL2", "ROWNUM", "ROWID"}


def _table_name(t: exp.Table) -> str:
    return ".".join(p.name for p in [t.args.get("db"), t.this] if p).lower() or t.name.lower()


def _join_type(j: exp.Join) -> str:
    side = str(j.args.get("side") or "").upper()
    kind = str(j.args.get("kind") or "").upper()
    on = j.args.get("on")
    using = j.args.get("using")
    if kind == "CROSS" or (on is None and not using):
        return "cross_join"
    if kind == "SEMI":
        return "semi_join"
    if kind == "ANTI":
        return "anti_join"
    if side == "LEFT":
        return "left_outer_join"
    if side == "RIGHT":
        return "right_outer_join"
    if side == "FULL":
        return "full_outer_join"
    return "inner_join"


def analyze_statement(sql_text: str) -> StmtAnalysis:
    kind = sql_text.split(None, 1)[0].upper()
    a = StmtAnalysis(kind=kind)

    try:
        tree = sqlglot.parse_one(sql_text, read="oracle")
    except Exception:
        a.parse_ok = False
        return a
    if tree is None:
        a.parse_ok = False
        return a

    # Writes: the target of INSERT/UPDATE/DELETE/MERGE.
    write_target = None
    if isinstance(tree, (exp.Insert, exp.Update, exp.Delete, exp.Merge)):
        this = tree.this
        if isinstance(this, exp.Schema):     # INSERT INTO t (cols)
            this = this.this
        if isinstance(this, exp.Table):
            write_target = this
            a.writes.add(_table_name(this))

    # Reads: every other table reference.
    for t in tree.find_all(exp.Table):
        if write_target is not None and t is write_target:
            continue
        a.reads.add(_table_name(t))

    # Set-based signals.
    a.joins = len(list(tree.find_all(exp.Join)))
    a.window_funcs = len(list(tree.find_all(exp.Window)))
    a.has_group_by = tree.find(exp.Group) is not None
    a.aggregates = len(
        [f for f in tree.find_all(exp.AggFunc)]
    )

    # Database operations (typed) for the DBOperation nodes / scorer weights.
    for j in tree.find_all(exp.Join):
        a.operations.append(_join_type(j))
        on = j.args.get("on")
        if on is not None and j.find(exp.EQ) is None:
            a.operations.append("non_equi_join")
    if isinstance(tree, exp.Insert):
        a.operations.append("set_insert" if tree.find(exp.Select) else "insert")
    elif isinstance(tree, exp.Update):
        a.operations.append("set_update")
    elif isinstance(tree, exp.Delete):
        a.operations.append("set_delete")
    elif isinstance(tree, exp.Merge):
        a.operations.append("merge")
    if a.has_group_by or a.aggregates:
        a.operations.append("aggregate")
    if a.window_funcs:
        a.operations.append("window")
    if tree.find(exp.Union):
        a.operations.append("union")
    if tree.find(exp.Distinct):
        a.operations.append("distinct")

    # Referenced columns (capped to keep the graph readable).
    for col in tree.find_all(exp.Column):
        if col.name and col.name != "*":
            a.columns.add(col.name.lower())
        if len(a.columns) >= 25:
            break

    # Oracle-specific flags.
    for node_type, label in _ORACLE_FLAGS.items():
        if tree.find(node_type) is not None:
            a.oracle_specific.append(label)
    for fn in tree.find_all(exp.Anonymous):
        if fn.name and fn.name.upper() in _ORACLE_FUNC_NAMES:
            a.oracle_specific.append(f"oracle_func:{fn.name.upper()}")
    if "NEXTVAL" in sql_text.upper() or "CURRVAL" in sql_text.upper():
        a.oracle_specific.append("sequence_ref")

    # Transpile to Spark SQL (best effort).
    try:
        a.spark_sql = sqlglot.transpile(sql_text, read="oracle", write="spark")[0]
    except Exception:
        a.spark_sql = None

    return a
